
chrome.runtime.onInstalled.addListener(() => {
  console.log("Table Scraper Extension Installed");
});
